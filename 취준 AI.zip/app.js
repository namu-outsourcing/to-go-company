const API_KEY = "AIzaSyDLmIHoSKXEdU-hX7ZiVmV9xj21hX493vI";

const app = {
    state: {
        jobs: [],
        editorJobId: null,
        editorActiveQIndex: 0
    },
    tempUploadJobId: null,

    init() {
        this.loadStorage();
        this.bindEvents();
        this.renderDashboard();
        this.initCharCounter();
        this.renderCalendar();
    },

    loadStorage() {
        const saved = localStorage.getItem('jobAgentData');
        if (saved) {
            try {
                this.state = JSON.parse(saved);
            } catch (e) { console.error("Storage parse error", e); }
        } else {
            this.state.jobs = [
                {
                    id: Date.now().toString(),
                    company: "우아한형제들",
                    role: "프론트엔드 개발자",
                    deadline: new Date(Date.now() + 86400000 * 2).toISOString().split('T')[0],
                    status: 'todo',
                    questions: ["지원동기를 작성해주세요.", "가장 큰 성취 경험을 적어주세요."],
                    answers: ["", ""],
                    pdfName: null
                }
            ];
            this.saveStorage();
        }
    },

    saveStorage() {
        localStorage.setItem('jobAgentData', JSON.stringify(this.state));
    },

    bindEvents() {
        document.querySelectorAll('.nav-item').forEach(item => {
            item.addEventListener('click', (e) => {
                e.preventDefault();
                document.querySelectorAll('.nav-item').forEach(nav => nav.classList.remove('active'));
                item.classList.add('active');

                const viewId = item.getAttribute('data-view');
                document.querySelectorAll('.view').forEach(view => view.classList.remove('active'));
                document.getElementById(`view-${viewId}`).classList.add('active');

                if (viewId === 'dashboard') {
                    this.renderDashboard();
                    this.renderCalendar();
                } else if (viewId === 'archive') {
                    this.renderArchive();
                }
            });
        });

        const btnParse = document.getElementById('btn-parse');
        if (btnParse) btnParse.addEventListener('click', () => this.fetchGeminiAPI());

        const docInput = document.getElementById('essay-input');
        if (docInput) {
            docInput.addEventListener('input', (e) => {
                const job = this.state.jobs.find(j => j.id === this.state.editorJobId);
                if (job) {
                    if (!job.answers) job.answers = [];
                    job.answers[this.state.editorActiveQIndex] = e.target.value;
                    this.saveStorage();
                }
            });
        }

        // Modal background click to close
        document.getElementById('job-modal').addEventListener('click', (e) => {
            if (e.target.id === 'job-modal') {
                this.closeModal();
            }
        });
    },

    // --- Gemini API ---
    async fetchGeminiAPI() {
        const urlInput = document.getElementById('job-url').value;
        if (!urlInput) {
            alert('채용 공고 URL이나 텍스트를 입력해주세요.');
            return;
        }

        const resultDiv = document.getElementById('parsing-result');
        const loader = resultDiv.querySelector('.loader');
        const dataDiv = resultDiv.querySelector('.parsed-data');

        resultDiv.classList.remove('hidden');
        loader.classList.remove('hidden');
        dataDiv.classList.add('hidden');

        const prompt = `
주어진 채용 공고 텍스트/URL에서 기업명, 직무, 마감일(YYYY-MM-DD 형식, 모르면 빈 문자열), 자소서 문항 배열을 찾아주세요.
응답은 반드시 아래 순수한 JSON 형식만 반환하세요.
{
  "company": "기업명",
  "role": "직무명",
  "deadline": "YYYY-MM-DD",
  "questions": ["문항1...", "문항2..."]
}

공고 내용:
${urlInput}
`;

        try {
            const resp = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${API_KEY}`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    contents: [{ parts: [{ text: prompt }] }],
                    generationConfig: { responseMimeType: "application/json" }
                })
            });
            const data = await resp.json();
            if (data.error) throw new Error(data.error.message);

            let textResponse = data.candidates[0].content.parts[0].text;
            if (textResponse.startsWith('```json')) {
                textResponse = textResponse.replace(/^```json\n?/, '').replace(/\n?```$/, '');
            }
            const parsed = JSON.parse(textResponse.trim());

            document.getElementById('p-company').value = parsed.company || "알 수 없음";
            document.getElementById('p-role').value = parsed.role || "알 수 없음";
            document.getElementById('p-deadline').value = parsed.deadline || "";

            const qList = document.getElementById('p-questions');
            qList.innerHTML = '';
            if (parsed.questions && parsed.questions.length > 0) {
                parsed.questions.forEach(q => {
                    qList.innerHTML += `<div class="q-badge">${q}</div>`;
                });
            } else {
                qList.innerHTML = '<div class="q-badge">추출된 문항이 없습니다.</div>';
            }

        } catch (e) {
            console.error(e);
            alert("API 통신 오류 (한도 초과 등): " + e.message + "\n\n(프로토타입 기능 체험을 위해 서버 통신 없이 모의 데모 데이터를 자동으로 채웁니다.)");
            document.getElementById('p-company').value = "당근마켓 (모의)";
            document.getElementById('p-role').value = "프론트엔드 엔지니어";
            const d = new Date(); d.setDate(d.getDate() + 7);
            document.getElementById('p-deadline').value = d.toISOString().split('T')[0];
            const qList = document.getElementById('p-questions');
            qList.innerHTML = `
                <div class="q-badge">당근마켓에 지원한 동기를 작성해주세요.</div>
                <div class="q-badge">프론트엔드 관련 프로젝트 경험을 기술해주세요.</div>
                <div class="q-badge">협업 중 갈등을 해결한 경험을 작성해주세요.</div>
            `;
        } finally {
            loader.classList.add('hidden');
            dataDiv.classList.remove('hidden');
        }
    },

    saveJob() {
        const company = document.getElementById('p-company').value;
        const role = document.getElementById('p-role').value;
        const deadline = document.getElementById('p-deadline').value;
        const qBadges = document.querySelectorAll('#p-questions .q-badge');
        const questions = Array.from(qBadges).map(b => b.innerText);

        const newJob = {
            id: Date.now().toString(), company, role, deadline, questions,
            answers: new Array(questions.length).fill(''), status: 'todo', pdfName: null
        };

        this.state.jobs.push(newJob);
        this.saveStorage();

        alert("공고가 성공적으로 등록되었습니다!");
        document.querySelector('.nav-item[data-view="dashboard"]').click();

        document.getElementById('job-url').value = '';
        document.getElementById('parsing-result').classList.add('hidden');
    },

    calcDDay(deadline) {
        if (!deadline) return "";
        const today = new Date(); today.setHours(0, 0, 0, 0);
        const dDate = new Date(deadline); dDate.setHours(0, 0, 0, 0);
        const diffTime = dDate - today;
        const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
        if (diffDays === 0) return "D-Day";
        if (diffDays > 0) return `D-${diffDays}`;
        return `D+${Math.abs(diffDays)}`;
    },

    renderDashboard() {
        const colTodo = document.getElementById('col-todo');
        const colApplied = document.getElementById('col-applied');
        const colInterview = document.getElementById('col-interview');
        if (!colTodo) return;

        colTodo.innerHTML = ''; colApplied.innerHTML = ''; colInterview.innerHTML = '';
        let counts = { todo: 0, applied: 0, interview: 0 };

        this.state.jobs.forEach(job => {
            if (job.status === 'fail' || job.status === 'pass') return;

            const dDayStr = this.calcDDay(job.deadline);
            let dDayClass = 'd-day-warning';
            if (dDayStr === "D-Day" || dDayStr.match(/^D-[1-3]$/)) dDayClass = 'd-day-danger';

            const isApplied = job.status === 'applied' || job.status === 'interview';

            let pdfBadgeHTML = '';
            if (job.pdfs && job.pdfs.length > 0) {
                pdfBadgeHTML = '<div style="margin-bottom:1rem;">' + job.pdfs.map(p => `<div class="pdf-badge" style="font-size:0.8rem; color:#fbcfe8; background:rgba(236, 72, 153, 0.1); padding:0.4rem; border-radius:6px; display:inline-flex; align-items:center; gap:4px; margin-bottom:0.3rem; margin-right:0.3rem; border:1px solid rgba(236, 72, 153, 0.2); cursor:pointer;" title="클릭 시 원본 다운로드" onclick="app.downloadPdf('${job.id}', '${p.name}', event)"><span class="material-symbols-rounded" style="font-size:1rem;">picture_as_pdf</span> ${p.name}</div>`).join('') + '</div>';
            } else if (job.pdfName) {
                pdfBadgeHTML = `<div class="pdf-badge" style="font-size:0.8rem; color:#fbcfe8; background:rgba(236, 72, 153, 0.1); padding:0.4rem; border-radius:6px; display:inline-flex; align-items:center; gap:4px; margin-bottom:1rem; border:1px solid rgba(236, 72, 153, 0.2); cursor:pointer;" title="클릭 시 다운로드 (MVP 모의)" onclick="app.downloadPdf('${job.id}', '${job.pdfName}', event)"><span class="material-symbols-rounded" style="font-size:1rem;">picture_as_pdf</span> ${job.pdfName}</div>`;
            }

            const cardHTML = `
                <div class="card ${job.status === 'interview' ? 'highlight' : ''}">
                    <div class="card-header">
                        ${dDayStr ? `<span class="d-day ${dDayClass}">${dDayStr}</span>` : ''}
                    </div>
                    <h4 style="cursor:pointer; color:var(--primary); display:inline-block;" title="눌러서 공고 상세 보기" onclick="app.showJobModal('${job.id}')">${job.company} <span class="material-symbols-rounded" style="font-size:1.1rem; vertical-align:middle; color:var(--text-muted); margin-left:2px;">info</span></h4>
                    <p>${job.role}</p>
                    ${pdfBadgeHTML}
                    <div class="actions" style="display:flex; gap:0.5rem; flex-wrap:wrap;">
                        ${isApplied ?
                    `<button class="btn-sm" onclick="app.openEditor('${job.id}')" style="background:rgba(16, 185, 129, 0.2); color:#a7f3d0; border-color:rgba(16, 185, 129, 0.3);">제출 서류 내용 보기</button>
                             <button class="btn-sm" onclick="app.triggerPdfUpload('${job.id}')" style="background:rgba(236, 72, 153, 0.2); color:#fbcfe8; border-color:rgba(236, 72, 153, 0.3);" title="추가 파일 첨부 (재업로드)">+ 서류 추가</button>` :
                    `<button class="btn-sm" onclick="app.openEditor('${job.id}')">자소서 쓰기</button>
                             <button class="btn-sm" onclick="app.triggerPdfUpload('${job.id}')" style="background:rgba(236, 72, 153, 0.2); color:#fbcfe8; border-color:rgba(236, 72, 153, 0.3);">+ 서류 원본 업로드</button>
                            `
                }
                        
                        <div style="flex-basis: 100%; height:0;"></div>
                        <select class="btn-sm" onchange="app.updateStatus('${job.id}', this.value)" style="width:100%; background:rgba(0,0,0,0.4); color:white; border: 1px solid rgba(255, 255, 255, 0.2); padding:0.6rem; margin-top:0.3rem;">
                            <option value="todo" ${job.status === 'todo' ? 'selected' : ''}>📋 상태 변경: 지원 준비중</option>
                            <option value="applied" ${job.status === 'applied' ? 'selected' : ''}>✅ 상태 변경: 지원 완료</option>
                            <option value="interview" ${job.status === 'interview' ? 'selected' : ''}>🧑‍💼 상태 변경: 서류합격 / 면접</option>
                            <option value="fail" ${job.status === 'fail' ? 'selected' : ''}>❌ 상태 변경: 서류/최종 불합격</option>
                            <option value="pass" ${job.status === 'pass' ? 'selected' : ''}>🎉 상태 변경: 최종 합격</option>
                        </select>
                    </div>
                </div>
            `;

            if (job.status === 'todo') { colTodo.innerHTML += cardHTML; counts.todo++; }
            if (job.status === 'applied') { colApplied.innerHTML += cardHTML; counts.applied++; }
            if (job.status === 'interview') { colInterview.innerHTML += cardHTML; counts.interview++; }
        });

        const cntTodo = document.querySelector('#col-todo').parentElement.querySelector('.count');
        if (cntTodo) cntTodo.innerText = counts.todo;
        const cntApplied = document.querySelector('#col-applied').parentElement.querySelector('.count');
        if (cntApplied) cntApplied.innerText = counts.applied;
        const cntInterview = document.querySelector('#col-interview').parentElement.querySelector('.count');
        if (cntInterview) cntInterview.innerText = counts.interview;
    },

    updateStatus(id, newStatus) {
        const job = this.state.jobs.find(j => j.id === id);
        if (job) {
            const oldStatus = job.status;
            job.status = newStatus;
            this.saveStorage();
            this.renderDashboard();
            this.renderCalendar();
            this.renderArchive();

            if (newStatus === 'fail' && oldStatus !== 'fail') alert(`[${job.company}] 불합격으로 표시되어 대시보드 상태창에서 숨김/보관 처리되었습니다.`);
            else if (newStatus === 'pass' && oldStatus !== 'pass') alert(`🎉 축하합니다! [${job.company}] 최종 합격 처리되어 대시보드에서 보관함으로 이동했습니다.`);
            else if ((oldStatus === 'fail' || oldStatus === 'pass') && (newStatus === 'todo' || newStatus === 'applied' || newStatus === 'interview')) {
                const statusName = newStatus === 'todo' ? '지원 전' : newStatus === 'applied' ? '지원 완료' : '면접 예정';
                alert(`[${job.company}] 공고가 '${statusName}' 상태로 변경되어 대시보드로 다시 복구되었습니다!`);
            }
        }
    },

    triggerPdfUpload(jobId) {
        this.tempUploadJobId = jobId;
        document.getElementById('global-pdf-upload').value = '';
        document.getElementById('global-pdf-upload').click();
    },

    handlePdfUpload(event) {
        const file = event.target.files[0];
        if (!file) return;

        const job = this.state.jobs.find(j => j.id === this.tempUploadJobId);
        if (job) {
            const today = new Date().toISOString().split('T')[0].replace(/-/g, '');
            const count = (job.pdfs && job.pdfs.length) ? job.pdfs.length + 1 : 1;
            const seqStr = count > 1 ? `_${count}` : '';
            const newFileName = `[${job.company}] ${job.role}_김철수_${today}${seqStr}.pdf`;

            const reader = new FileReader();
            reader.onload = (e) => {
                if (!job.pdfs) job.pdfs = [];
                job.pdfs.push({
                    name: newFileName,
                    originalName: file.name,
                    dataUrl: e.target.result
                });

                if (job.status === 'todo') job.status = 'applied';

                try {
                    this.saveStorage();
                    this.renderDashboard();
                    this.renderCalendar();
                    if (document.getElementById('view-archive').classList.contains('active')) {
                        this.renderArchive();
                    }
                    alert(`파일 업로드 완료!\n\n📄 실제 문서가 '${newFileName}' 이름으로 안전하게 저장되었습니다.\n(클릭 시 원본 데이터 그대로 다운로드 가능합니다)\n\n※ 이제 다중 파일 무제한 재업로드도 지원합니다!`);
                } catch (err) {
                    job.pdfs.pop(); // Revert on failure
                    alert("로컬 스토리지 데이터 한도(약 5MB)를 초과했습니다. 더 작은 용량의 파일을 올리거나 일부 공고를 지워 공간을 확보해주세요.");
                }
            };
            reader.readAsDataURL(file);
        }
        event.target.value = '';
    },

    downloadPdf(jobId, name, e) {
        if (e) e.stopPropagation();

        const job = this.state.jobs.find(j => j.id === jobId);
        if (job && job.pdfs) {
            const pdf = job.pdfs.find(p => p.name === name);
            if (pdf && pdf.dataUrl) {
                const link = document.createElement('a');
                link.href = pdf.dataUrl;
                link.download = pdf.name;
                link.click();
                return;
            }
        }

        // Fallback for legacy mocked pdf
        alert(`[주의] 모의 시연 때 올렸던 가짜 파일입니다. 빈 모의 문서로 대체 다운로드합니다:\n${name}`);
        const link = document.createElement('a');
        link.href = 'data:application/pdf;base64,JVBERi0xLjQKJcOkw7zDtsOwCjEgMCBvYmogPDwvVHlwZSAvQ2F0YWxvZyAvUGFnZXMgMiAwIFIgPj4gZW5kb2JqCjIgMCBvYmogPDwvVHlwZSAvUGFnZXMgL0tpZHMgWzMgMCBSXSAvQ291bnQgMSA+PiBlbmRvYmoKMyAwIG9iaiA8PC9UeXBlIC9QYWdlIC9QYXJlbnQgMiAwIFIgL01lZGlhQm94IFswIDAgNTk1LjI4IDg0MS44OV0gPj4gZW5kb2JqCnhyZWYKMCA0CjAwMDAwMDAwMDAgNjU1MzUgZiAKMDAwMDAwMDAxNSAwMDAwMCBuIAowMDAwMDAwMDYyIDAwMDAwIG4gCjAwMDAwMDAxMTUgMDAwMDAgbiAKdHJhaWxlciA8PC9TaXplIDQgL1Jvb3QgMSAwIFIgPj4Kc3RhcnR4cmVmCjE1NQolJUVPRg==';
        link.download = name;
        link.click();
    },

    renderArchive() {
        const grid = document.getElementById('archive-grid');
        if (!grid) return;
        grid.innerHTML = '';

        const archivedJobs = this.state.jobs.filter(j => j.status === 'fail' || j.status === 'pass');

        if (archivedJobs.length === 0) {
            grid.innerHTML = '<p style="color:var(--text-muted); font-size:1.1rem; grid-column:1/-1;">아직 보관/종료된 지원 내역이 없습니다.</p>';
            return;
        }

        archivedJobs.forEach(job => {
            const statusColor = job.status === 'pass' ? 'var(--success)' : 'var(--danger)';
            const statusText = job.status === 'pass' ? '🎉 최종 합격' : '❌ 지원 종료 (불합격)';
            let pdfBadgeHTML = '';
            if (job.pdfs && job.pdfs.length > 0) {
                pdfBadgeHTML = '<div style="margin-top:0.5rem;">' + job.pdfs.map(p => `<div class="pdf-badge" style="font-size:0.8rem; color:#fbcfe8; background:rgba(236, 72, 153, 0.1); padding:0.4rem; border-radius:6px; display:inline-flex; align-items:center; gap:4px; margin-bottom:0.3rem; margin-right:0.3rem; border:1px solid rgba(236, 72, 153, 0.2); cursor:pointer;" onclick="app.downloadPdf('${job.id}', '${p.name}', event)"><span class="material-symbols-rounded" style="font-size:1rem;">picture_as_pdf</span> ${p.name}</div>`).join('') + '</div>';
            } else if (job.pdfName) {
                pdfBadgeHTML = `<div class="pdf-badge" style="font-size:0.8rem; color:#fbcfe8; background:rgba(236, 72, 153, 0.1); padding:0.4rem; border-radius:6px; display:inline-flex; align-items:center; gap:4px; margin-top:0.5rem; border:1px solid rgba(236, 72, 153, 0.2); cursor:pointer;" onclick="app.downloadPdf('${job.id}', '${job.pdfName}', event)"><span class="material-symbols-rounded" style="font-size:1rem;">picture_as_pdf</span> ${job.pdfName}</div>`;
            }

            grid.innerHTML += `
                <div class="card" style="border-top: 4px solid ${statusColor}; margin:0;">
                    <div style="display:flex; justify-content:space-between; align-items:flex-start; margin-bottom:0.8rem;">
                        <h4 style="cursor:pointer; color:var(--text-main); font-size:1.2rem; margin:0; padding-right:1rem;" title="상세 보기" onclick="app.showJobModal('${job.id}')">${job.company}</h4>
                        <span style="color:${statusColor}; font-weight:600; font-size:0.9rem; white-space:nowrap;">${statusText}</span>
                    </div>
                    <p style="color:var(--text-muted); margin-bottom:0.5rem;">${job.role}</p>
                    ${pdfBadgeHTML}
                    <div class="actions" style="margin-top:1.5rem; display:flex; flex-wrap:wrap; gap:0.5rem;">
                        <button class="btn-sm" onclick="app.openEditor('${job.id}')" style="flex-basis:100%; padding:0.6rem; background:rgba(255,255,255,0.05); color:var(--text-main); border:1px solid var(--border-color);">자소서 문항 열람</button>
                        <select class="btn-sm" onchange="app.updateStatus('${job.id}', this.value)" style="flex-basis:100%; background:rgba(0,0,0,0.4); color:white; border: 1px solid rgba(255, 255, 255, 0.2); padding:0.6rem;">
                            <option value="fail" disabled selected>🔄 실수로 누르셨나요? (대시보드 복구)</option>
                            <option value="todo">대시보드 복구: 지원 준비중</option>
                            <option value="applied">대시보드 복구: 지원 완료</option>
                            <option value="interview">대시보드 복구: 면접 예정</option>
                            <option value="fail" ${job.status === 'fail' ? 'selected' : ''}>현재 상태 유지 (불합격)</option>
                            <option value="pass" ${job.status === 'pass' ? 'selected' : ''}>현재 상태 유지 (최종 합격)</option>
                        </select>
                    </div>
                </div>
            `;
        });
    },

    showJobModal(id) {
        const job = this.state.jobs.find(j => j.id === id);
        if (!job) return;
        document.getElementById('modal-company').innerText = job.company;
        document.getElementById('modal-role').innerText = job.role;
        document.getElementById('modal-deadline').innerText = job.deadline || '알 수 없음';

        const qList = document.getElementById('modal-questions');
        qList.innerHTML = '';
        if (job.questions && job.questions.length > 0) {
            job.questions.forEach((q, idx) => {
                qList.innerHTML += `<li style="margin-bottom:0.5rem;">${idx + 1}. ${q}</li>`;
            });
        } else {
            qList.innerHTML = '<li>등록된 문항이 없습니다.</li>';
        }

        document.getElementById('job-modal').classList.remove('hidden');
    },

    closeModal() {
        document.getElementById('job-modal').classList.add('hidden');
    },

    renderCalendar() {
        const calGrid = document.getElementById('calendar-grid');
        if (!calGrid) return;
        calGrid.innerHTML = '';

        const today = new Date();
        const year = today.getFullYear();
        const month = today.getMonth();

        const calMonthEl = document.getElementById('calendar-month');
        if (calMonthEl) calMonthEl.innerText = `${year}년 ${month + 1}월 (마감일 세부 일정)`;

        const firstDay = new Date(year, month, 1).getDay();
        const daysInMonth = new Date(year, month + 1, 0).getDate();

        const days = ['일', '월', '화', '수', '목', '금', '토'];
        for (let d of days) calGrid.innerHTML += `<div class="cal-day-header">${d}</div>`;

        for (let i = 0; i < firstDay; i++) calGrid.innerHTML += `<div class="cal-day empty"></div>`;

        for (let i = 1; i <= daysInMonth; i++) {
            const currentDateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(i).padStart(2, '0')}`;
            const dayJobs = this.state.jobs.filter(j => j.deadline === currentDateStr && (j.status !== 'fail' && j.status !== 'pass'));

            let jobsHTML = '';
            dayJobs.forEach(j => {
                jobsHTML += `<div class="cal-job-badge ${j.status}" style="cursor:pointer;" title="상세보기" onclick="app.showJobModal('${j.id}')">${j.company}</div>`;
            });

            calGrid.innerHTML += `
                <div class="cal-day ${i === today.getDate() ? 'today' : ''}">
                    <span class="date-num">${i}</span>
                    <div class="cal-jobs">${jobsHTML}</div>
                </div>
            `;
        }
    },

    openEditor(jobId) {
        document.querySelector('.nav-item[data-view="editor"]').click();
        const job = this.state.jobs.find(j => j.id === jobId);
        if (!job) return;
        this.state.editorJobId = jobId;
        this.state.editorActiveQIndex = 0;
        document.getElementById('editor-company').innerText = `[${job.company}] ${job.role}`;
        this.renderEditorQuestions(job);
        this.loadEditorQuestion(0);
    },

    renderEditorQuestions(job) {
        const qList = document.querySelector('.q-list');
        qList.innerHTML = '';
        if (!job.questions || job.questions.length === 0) {
            qList.innerHTML = '<div class="q-item active">문항이 없습니다.</div>';
            return;
        }
        job.questions.forEach((q, idx) => {
            const shortQ = q.length > 25 ? q.substring(0, 25) + '...' : q;
            qList.innerHTML += `
                <div class="q-item ${idx === 0 ? 'active' : ''}" data-idx="${idx}" onclick="app.loadEditorQuestion(${idx})">
                    ${idx + 1}. ${shortQ}
                </div>
            `;
        });
    },

    loadEditorQuestion(idx) {
        this.state.editorActiveQIndex = idx;
        const job = this.state.jobs.find(j => j.id === this.state.editorJobId);
        if (!job) return;

        document.querySelectorAll('.q-item').forEach(item => item.classList.remove('active'));
        const activeItem = document.querySelector(`.q-item[data-idx="${idx}"]`);
        if (activeItem) activeItem.classList.add('active');

        const qTitle = document.getElementById('current-q-title');
        qTitle.innerText = `${idx + 1}. ${job.questions[idx] || '문항 정보 없음'}`;

        const essayInput = document.getElementById('essay-input');
        essayInput.value = (job.answers && job.answers[idx]) ? job.answers[idx] : '';
        const counter = document.getElementById('char-current');
        if (counter) counter.innerText = essayInput.value.length;
    },

    initCharCounter() { }
};

document.addEventListener('DOMContentLoaded', () => { app.init(); });
